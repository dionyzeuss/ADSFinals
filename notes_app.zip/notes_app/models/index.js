const { Sequelize } = require('sequelize');
const config = require('../config/config.json')['development'];

const sequelize = new Sequelize(config.database, config.username, config.password, {
  host: config.host,
  dialect: config.dialect,
  port: config.port
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

console.log('Before requiring models');
db.User = require('./user')(sequelize, Sequelize);
db.Group = require('./group')(sequelize, Sequelize);
db.Note = require('./note')(sequelize, Sequelize);
db.NoteTask = require('./note_task')(sequelize, Sequelize);
db.Tag = require('./tag')(sequelize, Sequelize);
db.Task = require('./task')(sequelize, Sequelize);
db.UserTask = require('./user_task')(sequelize, Sequelize);
db.NoteShare = require('./note_share')(sequelize, Sequelize); // Add this line
console.log('After requiring models');

module.exports = db;
