const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const NoteTask = sequelize.define('NoteTask', {
    note_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    task_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    timestamps: false,
    tableName: 'note_task'
  });

  return NoteTask;
};
