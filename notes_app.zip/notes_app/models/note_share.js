module.exports = (sequelize, DataTypes) => {
    const NoteShare = sequelize.define('NoteShare', {
      share_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
      },
      note_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'notes',
          key: 'note_id'
        }
      },
      group_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'groups',
          key: 'group_id'
        }
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'users',
          key: 'user_id'
        }
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    }, {
      tableName: 'note_shares',
      timestamps: false
    });
  
    return NoteShare;
  };
  