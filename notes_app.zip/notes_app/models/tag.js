const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Tag = sequelize.define('Tag', {
    group_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    tag_name: {
      type: DataTypes.STRING,
      allowNull: false
    }
  }, {
    timestamps: false,
    tableName: 'tags'
  });

  return Tag;
};
