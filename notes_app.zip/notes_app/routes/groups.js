const express = require('express');
const router = express.Router();
const { Group, NoteShare } = require('../models'); 

router.get('/', async (req, res) => {
  try {
    const groups = await Group.findAll();
    res.json(groups);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/:groupId/shares', async (req, res) => {
  try {
    console.log(`Fetching shares for group ID: ${req.params.groupId}`);
    const shares = await NoteShare.findAll({ where: { group_id: req.params.groupId } });
    console.log(`Shares found: ${shares.length}`);
    res.json(shares);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
