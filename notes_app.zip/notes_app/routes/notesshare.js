
const express = require('express');
const router = express.Router();
const noteShareController = require('../controllers/noteshareController');

router.post('/share', noteShareController.shareNote);


router.get('/group/:groupId/shares', noteShareController.getNoteSharesByGroupId);


router.put('/share/:shareId', noteShareController.updateNoteShare);


router.delete('/share/:shareId', noteShareController.deleteNoteShare);


router.get('/test', noteShareController.testNoteEndpoint);

module.exports = router;
