const express = require('express');
const bodyParser = require('body-parser');
const db = require('./models');
const userRoutes = require('./routes/users');
const groupRoutes = require('./routes/groups');
const noteRoutes = require('./routes/notes');
const noteShareRoutes = require('./routes/notesshare');
const tagRoutes = require('./routes/tags');
const taskRoutes = require('./routes/tasks');

const app = express();
app.use(bodyParser.json());


app.get('/', (req, res) => {
  res.send('Welcome to the Notes App!');
});

// Define routes
app.use('/users', userRoutes);
app.use('/groups', groupRoutes);
app.use('/notes', noteRoutes);
app.use('/noteshares', noteShareRoutes); 
app.use('/tags', tagRoutes);
app.use('/tasks', taskRoutes);

// Sync database and start server
db.sequelize.sync().then(() => {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}).catch((err) => {
  console.error('Unable to connect to the database:', err);
});

module.exports = app;
