const { NoteShare } = require('../models');

exports.shareNote = async (req, res) => {
  try {
    const { noteId, groupId, userId } = req.body;

    const existingShare = await NoteShare.findOne({
      where: {
        note_id: noteId,
        group_id: groupId,
        user_id: userId
      }
    });

    if (existingShare) {
      return res.status(400).json({ error: 'Note share already exists for this user in the group' });
    }

    const share = await NoteShare.create({
      note_id: noteId,
      group_id: groupId,
      user_id: userId
    });

    res.json({ success: true, share });
  } catch (error) {
    console.error('Error in POST /share:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.getNoteSharesByGroupId = async (req, res) => {
  try {
    const { groupId } = req.params;
    const shares = await NoteShare.findAll({ where: { group_id: groupId } });

    if (shares.length === 0) {
      return res.status(404).json({ error: 'No note shares found for this group' });
    }

    res.json(shares);
  } catch (error) {
    console.error('Error in GET /group/:groupId/shares:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.updateNoteShare = async (req, res) => {
  try {
    const { shareId } = req.params;
    const { noteId, groupId, userId } = req.body;

    const share = await NoteShare.findByPk(shareId);
    if (!share) {
      return res.status(404).json({ error: 'Note share not found' });
    }

    share.note_id = noteId;
    share.group_id = groupId;
    share.user_id = userId;
    await share.save();

    res.json({ success: true, share });
  } catch (error) {
    console.error('Error in PUT /share/:shareId:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.deleteNoteShare = async (req, res) => {
  try {
    const { shareId } = req.params;

    const share = await NoteShare.findByPk(shareId);
    if (!share) {
      return res.status(404).json({ error: 'Note share not found' });
    }

    await share.destroy();
    res.json({ success: true });
  } catch (error) {
    console.error('Error in DELETE /share/:shareId:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.testNoteEndpoint = (req, res) => {
  res.json({ message: 'Notes endpoint is working' });
};
