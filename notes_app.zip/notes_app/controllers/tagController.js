const { Tag } = require('../models');

exports.getAllTags = async (req, res) => {
  try {
    const tags = await Tag.findAll();
    res.json(tags);
  } catch (error) {
    console.error('Error in getting tags:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.createTag = async (req, res) => {
  try {
    const { name } = req.body;
    const tag = await Tag.create({ name });
    res.status(201).json(tag);
  } catch (error) {
    console.error('Error in creating tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

exports.getTagById = async (req, res) => {
  try {
    const { id } = req.params;
    const tag = await Tag.findByPk(id);
    if (!tag) {
      return res.status(404).json({ error: 'Tag not found' });
    }
    res.json(tag);
  } catch (error) {
    console.error('Error in getting tag by ID:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.updateTag = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    const tag = await Tag.findByPk(id);
    if (!tag) {
      return res.status(404).json({ error: 'Tag not found' });
    }
    await tag.update({ name });
    res.json(tag);
  } catch (error) {
    console.error('Error in updating tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.deleteTag = async (req, res) => {
  try {
    const { id } = req.params;
    const tag = await Tag.findByPk(id);
    if (!tag) {
      return res.status(404).json({ error: 'Tag not found' });
    }
    await tag.destroy();
    res.json({ success: true });
  } catch (error) {
    console.error('Error in deleting tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
