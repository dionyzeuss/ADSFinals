const { Group } = require('../models');


exports.getAllGroups = async (req, res) => {
  try {
    const groups = await Group.findAll();
    res.json(groups);
  } catch (error) {
    console.error('Error in getting groups:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.createGroup = async (req, res) => {
  try {
    const { name } = req.body;
    const group = await Group.create({ name });
    res.status(201).json(group);
  } catch (error) {
    console.error('Error in creating group:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.getGroupById = async (req, res) => {
  try {
    const { id } = req.params;
    const group = await Group.findByPk(id);
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    res.json(group);
  } catch (error) {
    console.error('Error in getting group by ID:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.updateGroup = async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    const group = await Group.findByPk(id);
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    await group.update({ name });
    res.json(group);
  } catch (error) {
    console.error('Error in updating group:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.deleteGroup = async (req, res) => {
  try {
    const { id } = req.params;
    const group = await Group.findByPk(id);
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    await group.destroy();
    res.json({ success: true });
  } catch (error) {
    console.error('Error in deleting group:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
